var gameName = "Water Sort Puzzle";
var Storage_manager;
var Current_level = document.getElementById("currentlevel");

var gameStorage = {
  retrieve: function() {
   this.file1 = localStorage.getItem(gameName);
   this.file2 = JSON.parse(this.file1);
  // console.log(this.file2);
    if (this.file2 == null) {
      Storage_manager = {
        currentlvl: 1,
        lvltype: 0,
        sound: "off"
      }
      gameStorage.store(Storage_manager);
  }
  else {
    Storage_manager = this.file2;
    Current_level.innerText = Storage_manager.currentlvl;
  }
  
  },
  store: function(file) {
    this.file = JSON.stringify(file);
    localStorage.setItem(gameName, this.file);
  },
 verify: function() {
   if (Storage_manager.currentlvl >= 6&& Storage_manager.currentlvl < 15) {
     Storage_manager.lvltype = 1;
     gameStorage.store(Storage_manager);
   }
   
   if (Storage_manager.currentlvl >= 15&& Storage_manager.currentlvl < 21) {
     Storage_manager.lvltype = 2;
     gameStorage.store(Storage_manager);
   }  
   
    if (Storage_manager.currentlvl >= 21 && Storage_manager.currentlvl < 31) {
      Storage_manager.lvltype = 3;
      gameStorage.store(Storage_manager);
    }  
    
  if (Storage_manager.currentlvl >= 31 && Storage_manager.currentlvl < 36) {
    Storage_manager.lvltype = 0;
    gameStorage.store(Storage_manager);
  }
  
if (Storage_manager.currentlvl >= 36 && Storage_manager.currentlvl < 46) {
  Storage_manager.lvltype = 3;
  gameStorage.store(Storage_manager);
}

if (Storage_manager.currentlvl >= 46 && Storage_manager.currentlvl < 56) {
  Storage_manager.lvltype = 2;
  gameStorage.store(Storage_manager);
}

if (Storage_manager.currentlvl >= 56 && Storage_manager.currentlvl < 66) {
  Storage_manager.lvltype = 7;
  gameStorage.store(Storage_manager);
}

if (Storage_manager.currentlvl >= 66 && Storage_manager.currentlvl < 86) {
  Storage_manager.lvltype = 3;
  gameStorage.store(Storage_manager);
}

if (Storage_manager.currentlvl >= 86 && Storage_manager.currentlvl < 120) {
  Storage_manager.lvltype = 2;
  gameStorage.store(Storage_manager);
}

if (Storage_manager.currentlvl >= 120 && Storage_manager.currentlvl < 130) {
  Storage_manager.lvltype = 1;
  gameStorage.store(Storage_manager);
}

if (Storage_manager.currentlvl >= 130 && Storage_manager.currentlvl < 140) {
  Storage_manager.lvltype = 0;
  gameStorage.store(Storage_manager);
}

if (Storage_manager.currentlvl >= 140 && Storage_manager.currentlvl < 160) {
  Storage_manager.lvltype = 7;
  gameStorage.store(Storage_manager);
}

if (Storage_manager.currentlvl >= 160 && Storage_manager.currentlvl < 200) {
  Storage_manager.lvltype = 3;
  gameStorage.store(Storage_manager);
}
if (Storage_manager.currentlvl >= 200) {
  
  Storage_manager.lvltype = 7;
  gameStorage.store(Storage_manager);
}

 }
}
gameStorage.retrieve();
Current_level.innerText = Storage_manager.currentlvl;
function showtoast(message) {
  alert(message);
}
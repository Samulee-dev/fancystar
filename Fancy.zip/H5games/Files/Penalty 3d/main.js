
var Storage_manager;
var start = false;
var winorlose = document.getElementById("winorlose");
var Sc = document.getElementById("sc");
var Message_cont = document.getElementById("messagecont1").style;
var Message_cont2 = document.getElementById("messagecont2").style;
var Message_cont3 = document.getElementById("messagecont3").style;
var gameCloud;
var gameCloud1;
var gameField;
var gameCrowd;
var goalPost;
var gameBall;
var goalkeeper;
var gamePlayer;
var gameArrow;
let mathsto = setInterval(() => {
  math1 = Math.floor(Math.random() * 3) + 1;
}, 100)
setTimeout(() => {
  
  console.log(math1);
}, 1000)
var Power_val = document.getElementById("power").style;
var Btn = document.getElementById("btn");
var Power_cont = document.getElementById("powercont");
gameCloud = new component(innerWidth, innerHeight, "Cloud.png", 0, 0, "image", 0);
gameCloud1 = new component(innerWidth, innerHeight, "Cloud_1.png", 0, 0, "image", 0);
gameField = new component(innerWidth, innerHeight + 200, "field.png", 0, -100, "image", 0)
gameCrowd = new component(innerWidth, 222, "crowd.png", 0, 0, "image", 0)
goalPost = new component(180, 112, "goalpost.png", innerWidth/2 -(180/2), 140, "image", 0)

goalkeeper = new component(150, 120, "gk_1.png", (innerWidth/2 - 150/2), goalPost.y + 20, "animegk", 0);
goalkeeper2 = new component(0, 0, "gk_1.png", (innerWidth/2 - 150/2), goalPost.y + 20, "animegk2", 0);
goalkeeper3 = new component(0, 0, "gk_1.png", (innerWidth/2 - 150/2), goalPost.y + 20, "animegk3", 0);
gameArrow = new component(50, 50, "arrow.png", goalkeeper.x, goalkeeper.y + 75, "image", 0);
gameArrow.speedX = 3;
let h
gameBall = new component(50, 50, "ball.png", (innerWidth/2 - 50/2), goalkeeper.y + 222, "anime", 0);
//gameBall2 = new component(0, 0, "ball.png", innerWidth - 180, innerHeight - 100, "anime", 0);

//gamePlayerbg = new component(180, 180, "player_1.png", innerWidth - 300, innerHeight - 170, "image", 0);

gamePlayer = new component(180, 180, "player_1.png", gameBall.x - 120, gameBall.y - 60, "animeply", 0);

myGameArea.start();
let it = 1;
let itt = 1;
 function Animategk() {
    
  }
  let aply;
 
  function AnimatePly() {
   aply = setInterval(() => {
      
    }, 1000);
  }
  AnimatePly();
Animategk();
const power = {
  increase : false,
  value : 150,
  speed : 0.5
}
var touch
let tt
Btn.addEventListener("touchstart", () => {
if (start == true) {
  

  touch = true
  
  setTimeout(() => {
    gameArrow.speedX = 0;
    if (touch == true) {
    power.increase = true;
    tt = false;
    }
    else{ 
      tt = true
      power.increase = false;
    }
  }, 100);
}
});
Btn.addEventListener("touchend", () => {
  if (start == true) {
  touch = false
  if (tt == false) {
  Btn.style.display = "none";
  gameArrow.speedX = 0;
  
    power.increase = false;
clearInterval(aply);

gamePlayer.speedY = -2;
let plyloop = setInterval(() => {
    currentIndex2 = (currentIndex2 + 1) % img2.length;
  }, 80)
 
setTimeout(() => {
  parent.postMessage("kick", "*")
  gamePlayer.speedY = 0;
  Ballmove();
}, 850);
setTimeout(() => {
  clearInterval(plyloop);
}, 1500)
}
}
});
function Powerinc() {
  Power_val.marginTop = power.value + "px";
  power.speed = 0.25;
  
  console.log(power.value);
}
let tch = 1;
let tch2 = 1;



function Ballmove() {
  
 Move();
}
let mgl = document.getElementById("mgl")
  let Rd_v
 
  function Goalget(bool) {
    if (bool == true) {
      Rd_v = document.getElementById('td' + Session_array.currentround)
      Rd_v.innerText = "✅";
      if (Round_val.innerText == "One") {
      Session_array.gamerd1 = "✅";
      
      Stores(Session_array);
      }
      
      if (Round_val.innerText == "Two") {
      Session_array.gamerd2 = "✅";
     
      Stores(Session_array);
      }
      if (Round_val.innerText == "Three") {
        
      Session_array.gamerd3 = "✅";
   
      Stores(Session_array);
      }
  if (Round_val.innerText == "Four") {
 
      Session_array.gamerd4 = "✅";
      Stores(Session_array);
      }
   if (Round_val.innerText == "Five") {
      Session_array.gamerd5 = "✅";
      
      Stores(Session_array);
      }
         
          
      
      Message_cont2.display = "block";
     Session_array.currentround = Session_array.currentround + 1;
     Stores(Session_array);
    }
    else {
      let msh = "";
      if (msh != "y") {
  Rd_v = document.getElementById('td' + Session_array.currentround)
      Rd_v.innerText = "❌";
      if (Round_val.innerText == "One") {
      Session_array.gamerd1 = "❌";
      Session_array.gamerd1v = "";
      Stores(Session_array);
      }
      
      if (Round_val.innerText == "Two") {
      Session_array.gamerd2 = "❌";
      Session_array.gamerd2v = "";
      Stores(Session_array);
      }
      if (Round_val.innerText == "Three") {
      Session_array.gamerd3 = "❌";
      Session_array.gamerd3v = "";
      Stores(Session_array);
      }
  if (Round_val.innerText == "Four") {
      Session_array.gamerd4 = "❌";
      Session_array.gamerd4v = "";
      Stores(Session_array);
      }
   if (Round_val.innerText == "Five") {
      Session_array.gamerd5 = "❌";
      Session_array.gamerd5v = "";
      Stores(Session_array);
      }
             
      
      Session_array.currentround = Session_array.currentround + 1;
      Stores(Session_array);
      Message_cont2.display = "block";
      mgl.innerText = "M I S S";
      console.log(gameArrow.x);
      msh = "y";
      }
}
setTimeout(() => {
  if (Session_array.currentround != 6) {
 
location.reload();

}
else {
 FinalSc();
}

}, 2000);
  }
 
  currentIndex3 = (currentIndex3 + 1) % img3.length;
  
  Message_cont.top = (innerHeight/2) - (250/2) + "px";
  Message_cont.left = (innerWidth/2) - (300/2) + "px";
  Message_cont2.top = (innerHeight / 2) - (200 / 2) + "px";
  Message_cont2.left = (innerWidth / 2) - (250 / 2) + "px";
  
  Message_cont3.top = (innerHeight / 2) - (200 / 2) + "px";
  Message_cont3.left = (innerWidth / 2) - (250 / 2) + "px";
/*   if (Storage.start == true) {
     start = true;
}*/
   
   function Play() {
     start = true;
     Message_cont.display = "none";
     parent.postMessage("play", "*")
   }
 function Exit() {
sessionStorage.removeItem("Penalty 3d");
   parent.postMessage("exit", '*');
   
 }
 function Replay() {
   sessionStorage.removeItem("Penalty 3d");
   location.reload()
 }
 
 
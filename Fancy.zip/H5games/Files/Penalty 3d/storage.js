var Round_val = document.getElementById("round");

var Round_one = document.getElementById("td1");
var Round_two = document.getElementById("td2");
var Round_three = document.getElementById("td3");
var Round_four = document.getElementById("td4");
var Round_five = document.getElementById("td5");
var gameName = "Penalty 3d";
let storage = localStorage.getItem(gameName);
var Session_storage = sessionStorage.getItem(gameName);
var Session_array


if (storage == null) {
  Storage_manager = {
    
    highscore1: 0,
    highscore2: 0
    
  }
  Store(Storage_manager);
}
else {
  Storage_manager = JSON.parse(storage);

     
}
if (Session_storage == null) {
  Session_array = {
    session: false,
    currentround: 1,
    gamerd1: '',
    gamerd2: '',
    gamerd3: '',
    gamerd4: '',
    gamerd5: '',
    gamerd1v: '1',
      gamerd2v: '1',
      gamerd3v: '1',
      gamerd4v: '1',
      gamerd5v: '1'
  }
  Stores(Session_array);
}
else {
  Session_array = JSON.parse(Session_storage);
  Session_array.session = true;
  Stores(Session_array)
  start = true;
}

function Store(file) {
 this.file = JSON.stringify(file)
  localStorage.setItem(gameName, this.file);
 
}
function Stores(file) {
  this.file = JSON.stringify(file)
  sessionStorage.setItem(gameName, this.file);

}
if (Session_array.session == true) {
       Message_cont.display = "none";
     }
     let crd = Session_array.currentround;
function ToNRD() {
 
if (crd == 1) {
  Round_val.innerText = "One";
}
if (crd == 2) {
  Round_val.innerText = "Two"
}
if (crd == 3) {
  Round_val.innerText = "Three"
}
if (crd == 4) {
  Round_val.innerText = "Four"
  
}
if (crd == 5) {
  Round_val.innerText = "Five";
}

}
Round_one.innerText = Session_array.gamerd1;
Round_two.innerText = Session_array.gamerd2;
Round_three.innerText = Session_array.gamerd3;
Round_four.innerText = Session_array.gamerd4;
Round_five.innerText = Session_array.gamerd5;
ToNRD();
/*if (Session_array.gamerd1v == 1) {
alert(Session_array.gamerd1v)
}*/
function FinalSc() {
   let score = 0;
   let score2 = 0
   if  (Session_array.gamerd1v != "") {
     score = score + 1;
   }
   if (Session_array.gamerd2v != "") {
     score = score + 1;
   }
   if (Session_array.gamerd3v != "") {
     score = score + 1;
   }
   if (Session_array.gamerd4v != "") {
     score = score + 1;
   }
   if (Session_array.gamerd5v != "") {
     score = score + 1;
   }
  score2 = (5 - score);
  if (score > score2) {
    winorlose = "WIN";
  }
  else {
    winorlose.innerText = "LOSE";
  }
  Sc.innerText = score + " : " + score2;
  if (score > Storage_manager.highscore1) {
    document.getElementById("nhsc").innerText = "New HighScore";
    Storage_manager.highscore1 = score;
    Storage_manager.highscore2 = score2;
    Store(Storage_manager);
  }
  else {
    document.getElementById("nhsc").innerText = "";
  }
 Message_cont3.display = "block";
document.getElementById("rp").style.display = "block";
document.getElementById("ext").style.display = "block";
document.getElementById("rhsc").style.display = "block";
 }  
 document.getElementById("hscd").innerHTML = "HighScore" + `<br>` + Storage_manager.highscore1 + " : " + Storage_manager.highscore2;
 function Rhsc() {
   localStorage.removeItem(gameName);
   alert("Game Data Erased");
   
   sessionStorage.removeItem(gameName);
   location.reload();
 }
 
 
 
  
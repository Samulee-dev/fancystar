var myGameBike;
var myBackground;
var myBackground2;
var gameTraffic1;
var gameTraffic2;
var gameTraffic3;
var gameTraffic4;
var Left_btn = document.getElementById("btnleft");
var Right_btn = document.getElementById("btnright");
var Brake_btn = document.getElementById("btnbrake");

var Speed_val = document.getElementById("speed");
var Score_val = document.getElementById("score");
let speed = 0;
let score = 0;
let scoretime;
window.addEventListener("message", (event) => {
 if (event.data == "load") {
   setTimeout(() => {
     can.width = innerWidth;
     can.height = innerHeight;
    myBackground = new component(innerWidth , innerHeight + 50,"bg1.png", 0, 0, "image");
myBackground2 = new component(innerWidth , innerHeight + 50,"bg1.png", 0, -(innerHeight), "image");
gameTraffic1 = new component(120 , 100,"car1_a.png", 5 , -150, "image");
gameTraffic2 = new component(120 , 100,"car6_a.png", 65 , -350, "image");
gameTraffic3 = new component(120 , 100,"car4.png", 210 , 100, "image");
myGameBike = new component(80, 95, "redbike_1.png", innerWidth - 165,innerHeight - 152 , "image");
     myGameArea.start();
     setTimeout(() => {
       document.getElementById("counter").innerText = 2;
       setTimeout(() => {
         document.getElementById("counter").innerText = 1;
         setTimeout(() => {
           document.getElementById("counter").innerText = 0;
        document.getElementById("counter").style.display = "none"; 
        move("accelerate");
         }, 2600)
       }, 2000)
     }, 1000);
   }, 1000)
 }
})
/*

setTimeout(() => {
     can.width = innerWidth;
     can.height = innerHeight;
         myBackground = new component(innerWidth, innerHeight + 50, "bg1.png", 0, 0, "image");
         myBackground2 = new component(innerWidth, innerHeight + 50, "bg1.png", 0, -(innerHeight), "image");
         gameTraffic1 = new component(100, 100, "car1_a.png", 5, 100, "image");
     
         myGameBike = new component(80, 95, "redbike_1.png", innerWidth - 162, innerHeight - 152, "image");
     myGameArea.start();
     move("accelerate");
}, 1000)*/
//  myGamePiece = new component(30, 30, "smiley.gif", 10, 120, "image");
 // myBackground = new component(656, 270, "g.png", 0, 0, "image");
  //myGameArea.start();



var myGameArea = {


  start: function() {
    this.context = can.getContext("2d");
    this.frameNo = 0;
    this.interval = setInterval(updateGameArea, 20);
  },
  clear: function() {
   this.context.clearRect(0, 0, can.width, can.height);
  },
  stop: function() {
    clearInterval(this.interval);
  }
}

function component(width, height, color, x, y, type) {
  this.type = type;
  if (type == "image") {
    this.image = new Image();
    this.image.src = color;
  }
  this.width = width;
  this.height = height;
  this.speedX = 0;
  this.speedY = 0;
  this.x = x;
  this.y = y;
  this.update = function() {
    ctx = myGameArea.context;
    if (type == "image") {
      ctx.drawImage(this.image,
        this.x,
        this.y,
        this.width, this.height);
    } else {
      ctx.fillStyle = color;
      ctx.fillRect(this.x, this.y, this.width, this.height);
    }
   if (myBackground.y >= innerHeight) {
     myBackground.y = -(innerHeight);
   }
      if (myBackground2.y >= innerHeight) {
        myBackground2.y = -(innerHeight);
      }
  }
  this.newPos = function() {
    this.x += this.speedX;
    this.y += this.speedY;
    
  }
}

function updateGameArea() {
  myGameArea.clear();
  myBackground.newPos();
  myBackground.update();
  myBackground2.newPos();
  myBackground2.update();
  gameTraffic1.newPos();
  gameTraffic1.update();
  gameTraffic2.newPos();
gameTraffic2.update();
gameTraffic3.newPos();
gameTraffic3.update();
  myGameBike.newPos();
  myGameBike.update();
  
  
}
let speedtime;
function move(dir) {
  if (dir == "accelerate") {
    Math_math = Math.floor(Math.random() * 7) + 1;
    gameTraffic1.image.src = "car" + Math_math + "_a.png";
    setInterval(() => {
      if (Math_math == 1 || Math_math == 2) {
        gameTraffic1.width = 100;
      }
      else {
        gameTraffic1.width = 120;
      }
      
      if (myGameBike.x <= innerWidth - 205&& speed >= 76) {
        document.getElementById("dblsc").innerText = "2X";
      }
      else {
        document.getElementById("dblsc").innerText = "";
      }
    }, 10);
    
    setInterval(() => {
     let strtm = Math.floor(Math.random() * 2) + 1;
     if (strtm == 1&& gameTraffic1.x == 5&& gameTraffic1.y > (gameTraffic2.y + gameTraffic2.height + 20)) {
       gameTraffic1.speedX = 2;
     }
          if (strtm == 2 && gameTraffic1.x == 65&& gameTraffic1.y > (gameTraffic2.y + gameTraffic2.height + 20)) {
            gameTraffic1.speedX = -2;
          }
   
    }, 500);
    

 setInterval(() => {
   if (gameTraffic1.x < 5|| gameTraffic1.x > 65) {
     
     gameTraffic1.speedX = 0;
   }
 }, 10);
 
Bikemove();

let hittime = setInterval(() => {
  if (myGameBike.y <= (gameTraffic1.y + gameTraffic1.height)&& myGameBike.y > gameTraffic1.y&& myGameBike.x <= (gameTraffic1.x + gameTraffic1.width - 60)&& myGameBike.x > (gameTraffic1.x - 10)) {
   
  myGameBike.speedY = myBackground.speedY;
  gameTraffic1.speedY = myBackground.speedY;
  clearInterval(hittime);
  Hit();
//  clearInterval(movetime);
  clearInterval(speedtime);
  setTimeout(() => {
    myBackground.speedY = 0;
    myBackground2.speedY = 0;
    speed = 0;
    Speed_val.innerText = speed;
  }, 1000);
  }
  
  if (myGameBike.y <= (gameTraffic2.y + gameTraffic2.height) && myGameBike.y > gameTraffic2.y && myGameBike.x <= (gameTraffic2.x + gameTraffic2.width - 60) && myGameBike.x > (gameTraffic2.x - 10)) {
  myGameBike.speedY = myBackground.speedY;
  gameTraffic2.speedY = myBackground.speedY;
    clearInterval(hittime);
    Hit();
 //   clearInterval(movetime);
    clearInterval(speedtime);
    setTimeout(() => {
      myBackground.speedY = 0;
      myBackground2.speedY = 0;
      speed = 0;
      Speed_val.innerText = speed;
    }, 1000);
  }
  
if (myGameBike.y <= (gameTraffic3.y + gameTraffic3.height) && myGameBike.y > gameTraffic3.y && myGameBike.x <= (gameTraffic3.x + gameTraffic3.width - 60) && myGameBike.x > (gameTraffic3.x - 10)) {
  myGameBike.speedY = myBackground.speedY;
  
  clearInterval(hittime);
  Hit();
  //clearInterval(movetime);
  clearInterval(speedtime);
  setTimeout(() => {
    myBackground.speedY = 0;
    myBackground2.speedY = 0;
    speed = 0;
    Speed_val.innerText = speed;
  }, 1000);
}  
})
  }
} 

function clearmove() {
  
}
let movetime;
let speedtime2;

function Bikemove() {
  
  
  speedtime = setInterval(() => {
    
    speed++
    Speed_val.innerText = speed;
    }, 70);
  movetime = setInterval(() => {
    if (gameTraffic2.y > (gameTraffic1.y - gameTraffic1.height - 20)&& gameTraffic2.x == 65&& gameTraffic1.x == 65) {
      
      gameTraffic2.speedY = 2;
    }
 if (gameTraffic2.y > (gameTraffic1.y - gameTraffic1.height - 20) && gameTraffic2.x == 5&& gameTraffic1.x == 5) {
   gameTraffic2.speedY = 2;
 }   
 
 if (gameTraffic1.y > (gameTraffic2.y - gameTraffic2.height - 20) && gameTraffic1.x == 65 && gameTraffic2.x == 65) {
   gameTraffic1.speedY = 2;
 }
 if (gameTraffic1.y > (gameTraffic2.y - gameTraffic3.height - 20) && gameTraffic1.x == 5 && gameTraffic2.x == 5) {
   gameTraffic1.speedY = 2;
 }
    if (speed == 0) {
      myBackground.speedY = 0;
      myBackground2.speedY = 0;
      gameTraffic3.speedY = -4;
      gameTraffic1.speedY = 5;
      gameTraffic1.speedY = 5;
    }
    if (speed <= 20&& speed > 0) {
        myBackground.speedY = 2;
        myBackground2.speedY = 2;
        gameTraffic1.speedY = 4;
        gameTraffic2.speedY = 5;
        gameTraffic3.speedY = -4;
    }
    if (speed > 20&& speed < 60) {
      myBackground.speedY = 4;
      myBackground2.speedY = 4;
      gameTraffic1.speedY = 6;
      gameTraffic2.speedY = 6;
      gameTraffic3.speedY = -2;
    }
  if (speed >= 60 && speed < 100) {
    myBackground.speedY = 6;
    myBackground2.speedY = 6;
   gameTraffic1.speedY = 8;
   gameTraffic2.speedY = 9;
   gameTraffic3.speedY = 1;
  }  
  if (speed >= 100 && speed < 140) {
    myBackground.speedY = 8;
    myBackground2.speedY = 8;
    gameTraffic1.speedY = 10;
    gameTraffic2.speedY = 10;
    gameTraffic3.speedY = 2;
  }
  if (speed >= 140) {
    myBackground.speedY = 10;
    myBackground2.speedY = 10;
    gameTraffic1.speedY = 12;
    gameTraffic2.speedY = 11;
    gameTraffic3.speedY = 4;
  }
  if (speed >= 150) {
   clearInterval(speedtime);
   speed = 150;
  }
  if (gameTraffic1.y >= innerHeight) {
    gameTraffic1.y = -(innerHeight + innerHeight/2);
    let str = Math.floor(Math.random() * 2) + 1;
    if (str == 1) {
      gameTraffic1.x = 65;
    }
    if (str == 2) {
      gameTraffic1.x = 5;
    }
    Math_math = Math.floor(Math.random() * 7) + 1;
    gameTraffic1.image.src = "car" + Math_math + "_a.png";
  }
  
    if (gameTraffic2.y >= innerHeight) {
      gameTraffic2.y = -(innerHeight + innerHeight);
      let str2 = Math.floor(Math.random() * 2) + 1;
      if (str2 == 1&& gameTraffic1.x != 65) {
        gameTraffic2.x = 65;
      }
      if (str2 == 2&& gameTraffic1.x != 5) {
        gameTraffic2.x = 5;
      }
      Math_math2 = Math.floor(Math.random() * 7) + 1;
      if (Math_math2 == 1 || Math_math2 == 2) {
        
        gameTraffic2.width = 100;
      }
      else {
        gameTraffic2.width = 120;
      }
      gameTraffic2.image.src = "car" + Math_math2 + "_a.png";
    }
    
    if (gameTraffic3.y < -(300)) {
      gameTraffic3.y  = innerHeight + 50;
      Math_math3 = Math.floor(Math.random() * 7) + 1;
            if (Math_math3 == 1 || Math_math3 == 2) {
      
              gameTraffic3.width = 100;
            }
            else {
              gameTraffic3.width = 120;
            }
      gameTraffic3.image.src = "car" + Math_math3 + ".png";
if (myGameBike.x >= 190) {
gameTraffic3.x = 145;
}
}
if (gameTraffic3.y > innerHeight + 100) {
  Math_math3 = Math.floor(Math.random() * 7) + 1;
  if (Math_math3 == 1 || Math_math3 == 2) {
  
    gameTraffic3.width = 100;
  }
  else {
    gameTraffic3.width = 120;
  }
  gameTraffic3.image.src = "car" + Math_math3 + ".png";
  gameTraffic3.y = -90;
  let str3 = Math.floor(Math.random()  * 2) + 1;
  if (str3 == 1) {
    gameTraffic3.x = 145;
  }
  
  if (str3 == 2) {
    gameTraffic3.x = 210;
  }
  
}

//console.log(myGameBike.x);

  }, 10)
}
let lfttime;
let rghttime;
Left_btn.addEventListener("touchstart",() => {
  myGameBike.image.src = "redbike_2.png";
  setTimeout(() => {
    myGameBike.image.src = "redbike_3.png";
  }, 1);
  myGameBike.height = 85;
  myGameBike.width = 75;
  if (speed <= 20) {
    myGameBike.speedX = -2;
  }
else  if (speed > 20&& speed < 60) {
    myGameBike.speedX = -3;;
  }
  else if (speed >= 60 && speed < 100) {
    myGameBike.speedX = -4;;
  }
  else if (speed >= 100) {
    myGameBike.speedX = -5;;
  }
  lfttime = setInterval(() => {
    if (myGameBike.x < 0) {
      myGameBike.x = 0;
      myGameBike.speedX = 0
    }
  }, 10);
});
Left_btn.addEventListener("touchend", () => {
  myGameBike.height = 95;
  myGameBike.width = 80;
  myGameBike.speedX = 0;
  myGameBike.image.src = "redbike_1.png";
  clearInterval(lfttime);
})


Right_btn.addEventListener("touchstart", () => {
  myGameBike.image.src = "redbike_4.png";
  setTimeout(() => {
    myGameBike.image.src = "redbike_5.png";
  }, 1);
  myGameBike.height = 85;
  myGameBike.width = 75;
  if (speed <= 20) {
    myGameBike.speedX = 2;
  }
  else if (speed > 20 && speed < 60) {
    myGameBike.speedX = 3;
  }
  else if (speed >= 60 && speed < 100) {
    myGameBike.speedX = 4;
  }
  else if (speed >= 100) {
    myGameBike.speedX = 5;
  }
  rghttime = setInterval(() => {
        if (myGameBike.x > innerWidth - 80) {
          myGameBike.x = innerWidth - 80;
          myGameBike.speedX = 0;
        }
        }, 10);
});
Right_btn.addEventListener("touchend", () => {
  myGameBike.height = 95;
  myGameBike.width = 80;
  myGameBike.speedX = 0;
  myGameBike.image.src = "redbike_1.png";
});
Brake_btn.addEventListener("touchstart", () => {
  myGameBike.image.src = "redbike_1.png"
  clearInterval(speedtime);
speedtime2 = setInterval(() => {
speed--;
Speed_val.innerText = speed;
if (speed < 21) {
  speed = 20;
     clearInterval(speedtime2) 
}
}, 20);
});

Brake_btn.addEventListener("touchend", () => {
  clearInterval(speedtime2);
Bikemove();  
});

scoretime = setInterval(() => {
  if (speed > 70) {
    if (document.getElementById("dblsc") != "") {
      score++;
     // S_val.innerText = speed;
    }
    score++
    Score_val.innerText = score;
  } else {
    
  }
}, 1000);
var Math_math;
var gameArrayObj = {
  spd : ''
}
let pausetime;
function Pause() {
  gameArrayObj.spd = speed;
  clearInterval(movetime);
  clearInterval(speedtime);
  clearInterval(scoretime);
  clearInterval(speedtime2);
pausetime = setInterval(() => {
  myBackground.speedY = 0;
  myBackground2.speedY = 0;
  
gameTraffic1.speedY = 0;
gameTraffic2.speedY = 0;
gameTraffic3.speedY = 0;
}, 1);
Pause_cont.display = "block";
Left_btn.style.display = "none";
Right_btn.style.display = "none";
Brake_btn.style.display = "none";
document.getElementById("pausebtn").style.display = "none";
}

function Continue() {
  Pause_cont.display = "none";
  Left_btn.style.display = "block";
  Right_btn.style.display = "block";
  Brake_btn.style.display = "block";
  document.getElementById("pausebtn").style.display = "block";
  clearInterval(pausetime);
  speed = gameArrayObj.spd;
  Bikemove();
  scoretime = setInterval(() => {
    if (speed > 70) {
      if (document.getElementById("dblsc") == "2X") {
        score = score + 2;
        Score_val.innerText = score + 2;
        // S_val.innerText = speed;
      }
      score++
      Score_val.innerText = score;
    } else {
  
    }
  }, 1000);
}

function Hit() {
  setTimeout(() => {
    Pause_cont.display = "block";
    document.getElementById("pausecont").innerHTML = `  <h1 id="ph1">GAME OVER</h1>
  <button class="pbtn" style="margin-left: -25%; color: white; height: 50px" onclick="Restart()">RESTART</button>
  <button class="pbtn" style="margin-left: -25%; color: white; height: 50px; margin-top: 70px" onclick="Mainm()">MAINMENU</button>`;
  }, 400);
  if (score > Storage_M.highghscore1) {
    document.getElementById("newhsc").style.display = "block";
  Storage_M.highghscore1 = score;
  gameStorage.store(Storage_M);
  }
  

else if (score > Storage_M.highghscore2) {
  document.getElementById("newhsc").style.display = "block";
  Storage_M.highghscore2 = score;
  gameStorage.store(Storage_M);
}

else if (score > Storage_M.highghscore3) {
  document.getElementById("newhsc").style.display = "block";
  Storage_M.highghscore3 = score;
  gameStorage.store(Storage_M);
}
document.getElementById("hscc").style.display = "block";
}
function Mainm() {
  parent.postMessage("mainmenu", "*");
}
function Restart() {
  parent.postMessage("restart", "*");
  document.getElementById("pausecont").innerHTML = `<h1 id="ph1">Game Paused</h1>
  <button class="pbtn" style="margin-left: -25%; color: white; height: 50px" onclick="Continue()">CONTINUE</button>
  <button class="pbtn" style="margin-left: -25%; color: white; height: 50px; margin-top: 70px" onclick="Mainm()">MAINMENU</button>`
  
  location.reload();
}

if (sessionStorage.getItem("Motor Rider") == "load") {
  setTimeout(() => {
    can.width = innerWidth;
    can.height = innerHeight;
    myBackground = new component(innerWidth, innerHeight + 50, "bg1.png", 0, 0, "image");
    myBackground2 = new component(innerWidth, innerHeight + 50, "bg1.png", 0, -(innerHeight), "image");
    gameTraffic1 = new component(120, 100, "car1_a.png", 5, -150, "image");
    gameTraffic2 = new component(120, 100, "car6_a.png", 65, -350, "image");
    gameTraffic3 = new component(120, 100, "car4.png", 200, 100, "image");
    myGameBike = new component(80, 95, "redbike_1.png", innerWidth - 165, innerHeight - 152, "image");
    myGameArea.start();
    setTimeout(() => {
      document.getElementById("counter").innerText = 2;
      setTimeout(() => {
        document.getElementById("counter").innerText = 1;
        setTimeout(() => {
          document.getElementById("counter").innerText = 0;
          document.getElementById("counter").style.display = "none";
          move("accelerate");
        }, 2600)
      }, 2000)
    }, 1000);
  }, 1000);
  sessionStorage.removeItem("Motor Rider");
}

var Storage_M;
var gameName = "Motor Rider";
var gameStorage = {
  retrieve: function() {
    Storage_M = JSON.parse(localStorage.getItem(gameName));
  },
  store: function(file) {
    this.file = JSON.stringify(file);
    localStorage.setItem(gameName, this.file);
  }
  
}
gameStorage.retrieve();
var High_score1 = document.getElementById("hsc1");
var High_score2 = document.getElementById("hsc2");
var High_score3 = document.getElementById("hsc3");

High_score1.innerText = Storage_M.highghscore1;
High_score2.innerText = Storage_M.highghscore2;
High_score3.innerText = Storage_M.highghscore3;
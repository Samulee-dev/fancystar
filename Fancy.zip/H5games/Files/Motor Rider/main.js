setTimeout(() => {
  window.location.href = "main.html";
}, 3000);
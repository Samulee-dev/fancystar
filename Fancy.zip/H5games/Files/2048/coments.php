<?php
$c = $_REQUEST["c"];

$myfile = fopen("coments.txt", "a") or die("Unable to open file!");
$txt = "$c\n";
fwrite($myfile, $txt);
fclose($myfile);
?>
var Android_Files = document.getElementById("androidfiles")
var Android_http = new XMLHttpRequest();
var Android_response;

Android_http.onload = function() {
  Android_Files.style.height = "150px";
  Android_response = this.responseText;
  Android_Files.innerHTML = Android_response;
  let gg = Android_Files.getElementsByTagName("a")
 if (gg.length > 3&& gg.length <= 6) {
   Android_Files.style.height = "200px";
 }
 else if (gg.length > 6) {
   Android_Files.style.height = "290px";
 }
}
Android_http.open("Get", "Android_Games.txt", true);
Android_http.send();



var Java_Files = document.getElementById("javafiles")
var Java_http = new XMLHttpRequest();
var Java_response;

Java_http.onload = function() {
  Java_Files.style.height = "150px";
  Java_response = this.responseText;
  Java_Files.innerHTML = Java_response;
  let gg = Java_Files.getElementsByTagName("a")
  if (gg.length > 3 && gg.length <= 6) {
    Java_Files.style.height = "200px";
  }
  else if (gg.length > 6) {
    Java_Files.style.height = "290px";
  }
}
Java_http.open("Get", "Java_Games.txt", true);
Java_http.send();


var Psp_Files = document.getElementById("pspfiles")
var Psp_http = new XMLHttpRequest();
var Psp_response;

Psp_http.onload = function() {
  Psp_Files.style.height = "150px";
  Psp_response = this.responseText;
  Psp_Files.innerHTML = Psp_response;
  let gg = Psp_Files.getElementsByTagName("a")
  if (gg.length > 3 && gg.length <= 6) {
    Psp_Files.style.height = "200px";
  }
  else if (gg.length > 6) {
    Psp_Files.style.height = "290px";
  }
}
Psp_http.open("Get", "Psp_games.txt", true);
Psp_http.send();



var Html5_Files = document.getElementById("html5files")
var Html5_http = new XMLHttpRequest();
var Html5_response;

Html5_http.onload = function() {
  Html5_Files.style.height = "150px";
  Html5_response = this.responseText;
  Html5_Files.innerHTML = Html5_response;
  let gg = Html5_Files.getElementsByTagName("a")
  if (gg.length > 3 && gg.length <= 6) {
    Html5_Files.style.height = "200px";
  }
  else if (gg.length > 6) {
    Html5_Files.style.height = "290px";
  }
}
Html5_http.open("Get", "Html5_Games.txt", true);
Html5_http.send();
<?php
$n = $_REQUEST["n"];
$nn = json_decode($n, true);
$nnn = $nn["name"];
$check = readfile("$nnn");
if ($check != null) {
echo "$check";
}
else {
$myfile = fopen("$nnn", "w") or die("Unable to open file!");
$txt = $nn["username"];
$txt2 = $nn["email"]; 
$txt3 = $nn["password"];
echo "Creating Account...";
fwrite($myfile, "{,\nusername:$txt,\nemail:$txt2,\npassword:$txt3,\n}");
fclose($myfile);
}
?>
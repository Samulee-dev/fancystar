setTimeout(() => {
  document.getElementById("Filall").style.display = "none";
  document.getElementById("Filgames").style.display = "none";
  document.getElementById("Filmusics").style.display = "none";
  document.getElementById("Filmusics").style.display = "none";
  document.getElementById("Filvideos").style.display = "none";
  document.getElementById("Filwallpapers").style.display = "none";
  document.getElementById("Filebooks").style.display = "none";
  document.getElementById("Filapplications").style.display = "none";
  
var Innh_val = innerHeight;
var Heightt_val = Innh_val - 85 + "px";
document.getElementById("contb").style.height = Heightt_val;
document.getElementById("menu").style.height = Innh_val + "px";


}, 1000);
function Opm2() {
  document.getElementById("menu").style.display = "block";
  document.getElementById("menu").style.animationName = "example";
  document.getElementById("nav").style.animationName = "example2";
  document.getElementById("nav").style.webkitTransform = "rotate(-90deg)";
}
function Clm() {
  
  document.getElementById("menu").style.animationName = "exampleb";
  setTimeout(() => {
    document.getElementById("menu").style.display = "none";
  }, 1000);

  document.getElementById("nav").style.animationName = "example3";
  document.getElementById("nav").style.webkitTransform = "rotate(0deg)";

}
function Search() {
  var Filter_search = document.getElementById("filter").value;
  var Input_val = document.getElementById("search").value;
  
  if (Input_val != "") {
    var filterid
    if (Filter_search == "All") {
      filterid = "Filall";
      document.getElementById("Filgames").style.display = "none";
  document.getElementById("Filmusics").style.display = "none";
  document.getElementById("Filmusics").style.display = "none";
  document.getElementById("Filvideos").style.display = "none";
  document.getElementById("Filwallpapers").style.display = "none";
  document.getElementById("Filebooks").style.display = "none";
  document.getElementById("Filapplications").style.display = "none";
  
    }
    else if (Filter_search == "Games") {
      filterid = "Filgames";
      document.getElementById("Filall").style.display = "none";
  document.getElementById("Filmusics").style.display = "none";
  document.getElementById("Filmusics").style.display = "none";
  document.getElementById("Filvideos").style.display = "none";
  document.getElementById("Filwallpapers").style.display = "none";
  document.getElementById("Filebooks").style.display = "none";
  document.getElementById("Filapplications").style.display = "none";
  
    }
    else if (Filter_search == "Musics") {
      filterid = "Filmusics";
      document.getElementById("Filgames").style.display = "none";
  document.getElementById("Filmusics").style.display = "none";
  document.getElementById("Filall").style.display = "none";
  document.getElementById("Filvideos").style.display = "none";
  document.getElementById("Filwallpapers").style.display = "none";
  document.getElementById("Filebooks").style.display = "none";
  document.getElementById("Filapplications").style.display = "none";
  
    }
    else if (Filter_search == "Videos") {
      filterid = "Filvideos";
      document.getElementById("Filgames").style.display = "none";
  document.getElementById("Filmusics").style.display = "none";
  document.getElementById("Filmusics").style.display = "none";
  document.getElementById("Filall").style.display = "none";
  document.getElementById("Filwallpapers").style.display = "none";
  document.getElementById("Filebooks").style.display = "none";
  document.getElementById("Filapplications").style.display = "none";
      
    }
    else if (Filter_search == "Wallpapers") {
      filterid = "Filwallpapers";
      document.getElementById("Filgames").style.display = "none";
  document.getElementById("Filmusics").style.display = "none";
  document.getElementById("Filmusics").style.display = "none";
  document.getElementById("Filvideos").style.display = "none";
  document.getElementById("Filall").style.display = "none";
  document.getElementById("Filebooks").style.display = "none";
  document.getElementById("Filapplications").style.display = "none";
  
    }
    else if (Filter_search == "E-Books") {
      filterid = "Filebooks";
      document.getElementById("Filgames").style.display = "none";
  document.getElementById("Filmusics").style.display = "none";
  document.getElementById("Filmusics").style.display = "none";
  document.getElementById("Filvideos").style.display = "none";
  document.getElementById("Filwallpapers").style.display = "none";
  document.getElementById("Filall").style.display = "none";
  document.getElementById("Filapplications").style.display = "none";
    
    }
    else if (Filter_search == "Applications") {
      filterid = "Filapplications";
      document.getElementById("Filgames").style.display = "none";
  document.getElementById("Filmusics").style.display = "none";
  document.getElementById("Filmusics").style.display = "none";
  document.getElementById("Filvideos").style.display = "none";
  document.getElementById("Filwallpapers").style.display = "none";
  document.getElementById("Filebooks").style.display = "none";
  document.getElementById("Filall").style.display = "none";
  
    }
    document.getElementById("Suggested").style.display = "none";
    document.getElementById(filterid).style.display = "block";

    document.getElementById("sug").innerHTML = "Suggested Result For " + "'" + Input_val + "'";
    var input, filter, ul, li, a, i, txtValue;
    input = document.getElementById("search");
    filter = input.value.toUpperCase();
    ul = document.getElementById(filterid);
    li = ul.getElementsByTagName("li");
    //console.log(li);
    for (i = 0; i < li.length; i++) {
      a = li[i].getElementsByTagName("a")[0];
      txtValue = a.textContent || a.innerText;
      if (txtValue.toUpperCase().indexOf(filter) > -1) {
        li[i].style.display = "";

      } else {
        li[i].style.display = "none";

      }
    }
  }
  else {

  }
}



function Dark() {
  if (Mode_val == "dark" || txtdw == "dark") {
    sessionStorage.setItem("fancymode", "light");
    txtdw = "light";
    document.getElementById("dtxt").style.color = "black";

    document.getElementById("darkm").style.animationName = "dark";
    document.getElementById("darkm").style.marginLeft = "4px";
    document.getElementById("darkm").style.backgroundColor = "green";
    document.getElementById("dcover").style.backgroundColor = "white";
    document.getElementById("dcover").style.border = "2px solid black";
    document.getElementById("bdy2").style.backgroundImage = "url(/Images/sbg.png)";
    document.getElementById("menu").style.backgroundColor = "green";
    document.getElementById("search").style.backgroundColor = "white";
    document.getElementById("search").style.color = "black";
    document.getElementById("sug").style.backgroundColor = "greenyellow";
  }
  
  else if (Mode_val == "light" || txtdw == "light") {
    sessionStorage.setItem("fancymode", "dark");
    txtdw = "dark";
    document.getElementById("bdy2").style.backgroundImage = "url(/Images/darkbg.png)";
    document.getElementById("sglasss").style.backgroundColor = "black";
    document.getElementById("search").style.backgroundColor = "black";
    document.getElementById("search").style.color = "white";
    document.getElementById("sug").style.backgroundColor = "green";
    document.getElementById("menu").style.backgroundColor = "black";
    document.getElementById("dtxt").style.color = "white";
    document.getElementById("darkm").style.animationName = "dark1";
    
    document.getElementById("darkm").style.marginLeft = "42px";
    document.getElementById("darkm").style.backgroundColor = "blue";
    document.getElementById("dcover").style.backgroundColor = "black";
    document.getElementById("dcover").style.border = "2px solid white";
    
  }
}

var Nav = {
  games: function() {
    if (document.getElementById("subb").style.display == "block") {
      document.getElementById("subb").style.display = "none";

      document.getElementById("game").innerHTML = "Games 🔻";
      document.getElementById("subb2").style.display = "none";
      document.getElementById("subb3").style.display = "none";

    }
    else if (document.getElementById("subb").style.display != "block") {
      document.getElementById("subb").style.display = "block";
      document.getElementById("subb2").style.display = "block";
      document.getElementById("subb3").style.display = "block";
      document.getElementById("game").innerHTML = "Games 🔺";
    }
  },
  music: function() {
    if (document.getElementById("msub").style.display == "block") {
      document.getElementById("msub").style.display = "none";

      document.getElementById("music").innerHTML = "Musics 🔻";
      document.getElementById("msub2").style.display = "none";
      document.getElementById("msub3").style.display = "none";

    }
    else if (document.getElementById("msub").style.display != "block") {
      document.getElementById("msub").style.display = "block";
      document.getElementById("msub2").style.display = "block";
      document.getElementById("msub3").style.display = "block";
      document.getElementById("music").innerHTML = "Musics 🔺";
    }
  },
  video: function() {
    if (document.getElementById("vsub").style.display == "block") {
      document.getElementById("vsub").style.display = "none";

      document.getElementById("video").innerHTML = "Videos 🔻";
      document.getElementById("vsub2").style.display = "none";
      document.getElementById("vsub3").style.display = "none";

    }
    else if (document.getElementById("vsub").style.display != "block") {
      document.getElementById("vsub").style.display = "block";
      document.getElementById("vsub2").style.display = "block";
      document.getElementById("vsub3").style.display = "block";
      document.getElementById("video").innerHTML = "Videos 🔺";
    }
  }
}


function Searchq() {
  var Filter_search = document.getElementById("filter").value;
  var Input_val = document.getElementById("search").value; 
  if (Filter_search == "All"&& Input_val != "") {
    window.location.href = "All/search.html?="+Input_val;
  }
}